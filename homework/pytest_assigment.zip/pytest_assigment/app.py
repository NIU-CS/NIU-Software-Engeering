from assignment.score import format_student_result

demo_scores = [70, 80, 90]
print(format_student_result("Alice", demo_scores))