from assignment.score import calculate_average, highest_score, is_passing, format_student_result

def test_calculate_average():
    # 測試 calculate_average 函式
    pass

def test_highest_score():
    # 測試 highest_score 函式
    pass

def test_is_passing():
    # 測試 is_passing 函式
    pass

def test_format_student_result():
    # 測試 format_student_result 函式
    pass
