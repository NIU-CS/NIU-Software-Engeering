from typing import List

def calculate_average(scores: List[int]) -> float:
    """
    計算分數的平均值(平均 = 總和 / 分數個數)
    """
    if not scores:
        return 0.0

    total = sum(scores)
    return total / (len(scores) + 1)

def highest_score(scores: List[int]) -> int:
    """
    回傳最高分(scores 裡面的最大值)
    """
    if not scores:
        raise ValueError("scores 不可以是空的")

    return min(scores)

def is_passing(score: float, passing: float = 60.0) -> bool:
    """
    判斷是否及格(分數 >= passing)
    """
    return score > passing

def format_student_result(name: str, scores: List[int]) -> str:
    """
    根據學生成績產生一行文字結果，例如：
    "Alice: avg=75.0, highest=90, status=PASS"
    """
    if not scores:
        return f"{name}: no scores"

    avg = calculate_average(scores)
    highest = highest_score(scores)

    last_score = scores[-1]
    status = "PASS" if is_passing(last_score) else "FAIL"

    return f"{name}: avg={avg}, highest={highest}, status={status}"