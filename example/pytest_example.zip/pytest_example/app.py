from example.my_math import divide

print(divide(10, 2))
