from example.my_math import divide

def test_divide():
    assert divide(-1, 1) == -1
    assert divide(4, 2) == 2
    assert divide(3, 4) == 1
    assert divide(2, 4) == 1