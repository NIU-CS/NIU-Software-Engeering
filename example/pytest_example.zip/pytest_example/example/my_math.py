def divide(x, y):
    """
    計算兩數相除後以小數點第一位進行四捨五入
    """    
    return x / y